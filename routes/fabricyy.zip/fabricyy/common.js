function validateRequestBody(text) {
    return null;
}