const { pool } = require('../dbconfig');

//Checked: 4/4/23
module.exports = async (req, res) => {

  //Check body is empty
  if (req.body.constructor === Object && Object.keys(req.body).length === 0) 
  {
    res.status(200).json({ Type: "ERROR", Msg: "Oops! Empty Data Set in Hedaer on Get Fabric YY Requests" });
    return;
  }

  //Check element count
  if (Object.keys(req.body).length < 2) 
  {
    res.status(200).json({ Type: "ERROR", Msg: "Oops! Can't Find Correct Dataset to Get Fabric YY Requests" });
    return;
  }

  //Set varaiables from body parameters
  const var_username = req.body.username != null && req.body.username != undefined ? req.body.username : "";
  const var_typeid = req.body.typeid != null && req.body.typeid != undefined ? req.body.typeid : "";

  //Init variables
  var sqlqry = "";

  if (var_typeid === "ALL" && var_username != "")   //Query 01: get all request for user without deleted
  {
    sqlqry = `SELECT fabricyy_master.*,sys_customer.cus_name,sys_factory.fac_name 
    FROM fabricyy_master 
    INNER JOIN sys_customer ON fabricyy_master.cus_id = sys_customer.cus_id 
    INNER JOIN sys_factory ON fabricyy_master.fac_id = sys_factory.fac_id 
    WHERE fabricyy_master.fabyy_status != 'Delete' AND fabricyy_master.username = '${var_username}' 
    ORDER BY fabricyy_master.fabyy_id DESC;`;
  }
  else if (var_username != "" && var_username != "")  //Query 02: get specific request detail by user and id without deleted
  {
    sqlqry = `SELECT fabricyy_master.*,fabricyy_details.*,sys_customer.cus_name,sys_factory.fac_name 
    FROM fabricyy_master 
    INNER JOIN sys_customer ON fabricyy_master.cus_id = sys_customer.cus_id 
    INNER JOIN sys_factory ON fabricyy_master.fac_id = sys_factory.fac_id
	  LEFT JOIN fabricyy_details ON fabricyy_master.fabyy_id = fabricyy_details.fabyy_id 
    WHERE fabricyy_master.fabyy_status != 'Delete' AND fabricyy_master.username = '${var_username}' AND fabricyy_master.fabyy_id = '${var_typeid}';`;
  }
  else 
  {
    res.status(200).json({ Type: "ERROR", Msg: "Oops! Can't Find Correct Query Combination for Get Fabric YY Request List" });
    return;
  }

  if (sqlqry != "")   //Check for avalability of query
  {
    //Execute query
    pool.query(sqlqry, (error, results) => {
      if (error)  //if error
      {
        res.status(200).json({ Type: "ERROR", Msg: error.message });
        return;
      } 
      else  //if sucess
      {
        res.status(200).json({ Type: "SUCCESS", Data: results.rows });
        return;
      }
    })
  }
  else  //If query is blank
  {
    res.status(200).json({ Type: "ERROR", Msg: "Oops! Can't Find Correct Query Get Fabric YY Requests" });
    return;
  }
};